bl_info = {
    "name": "Custom Blender UI Skin V7",
    "author": "Custom",
    "version": (7, 0, 0),
    "blender": (5, 2, 0),
    "location": "3D View > N > Skin",
    "description": "Blender外侧UI独立背景皮肤",
    "category": "Interface",
}

import bpy
import gpu

from pathlib import Path

from bpy.props import (
    StringProperty,
    BoolProperty,
    FloatProperty,
    EnumProperty,
)

from gpu_extras.presets import draw_texture_2d


# =========================================================
# 区域映射
# =========================================================

AREA_TO_SLOT = {
    "OUTLINER": "outliner",
    "PROPERTIES": "properties",
    "DOPESHEET_EDITOR": "timeline",
    "GRAPH_EDITOR": "timeline",
    "NLA_EDITOR": "timeline",
    "TOPBAR": "topbar",
}


# =========================================================
# GPU缓存
# =========================================================

_TEXTURE_CACHE = {}
_HANDLERS = []


# =========================================================
# 图片读取
# =========================================================

def get_image(path):

    if not path:
        return None

    try:
        real_path = Path(bpy.path.abspath(path))

        if not real_path.exists():
            return None

        for image in bpy.data.images:

            try:
                if bpy.path.abspath(image.filepath) == str(real_path):
                    return image
            except Exception:
                pass

        return bpy.data.images.load(
            str(real_path),
            check_existing=True
        )

    except Exception:
        return None


# =========================================================
# 创建带透明度的GPU纹理
# =========================================================

def create_texture(slot, item):

    if not item.image_path:
        return None

    image = get_image(item.image_path)

    if image is None:
        return None

    try:

        width = int(image.size[0])
        height = int(image.size[1])

        if width <= 0 or height <= 0:
            return None

        pixels = list(image.pixels[:])

        opacity = max(
            0.0,
            min(
                1.0,
                float(item.opacity)
            )
        )

        # 修改Alpha
        for i in range(3, len(pixels), 4):
            pixels[i] *= opacity

        name = (
            "__CUSTOM_SKIN_V7_"
            + slot
            + "_"
            + str(id(item))
        )

        old = bpy.data.images.get(name)

        if old:

            try:
                bpy.data.images.remove(old)
            except Exception:
                pass

        new_image = bpy.data.images.new(
            name=name,
            width=width,
            height=height,
            alpha=True,
            float_buffer=True
        )

        new_image.pixels = pixels

        texture = gpu.texture.from_image(
            new_image
        )

        return {
            "texture": texture,
            "image": new_image,
            "width": width,
            "height": height,
        }

    except Exception:

        return None


# =========================================================
# 获取缓存纹理
# =========================================================

def get_texture(slot, item):

    key = (
        slot,
        item.image_path,
        round(item.opacity, 3),
        round(item.scale, 3),
        round(item.offset_x, 1),
        round(item.offset_y, 1),
        item.fit_mode,
    )

    if key in _TEXTURE_CACHE:
        return _TEXTURE_CACHE[key]

    # 删除同区域旧缓存
    for old_key in list(_TEXTURE_CACHE.keys()):

        if old_key[0] == slot:
            del _TEXTURE_CACHE[old_key]

    result = create_texture(
        slot,
        item
    )

    if result:
        _TEXTURE_CACHE[key] = result

    return result


# =========================================================
# 图片尺寸计算
# =========================================================

def calculate_size(
    area_width,
    area_height,
    image_width,
    image_height,
    mode,
    scale
):

    if image_width <= 0 or image_height <= 0:
        return 1, 1

    sx = area_width / image_width
    sy = area_height / image_height

    if mode == "FILL":

        factor = max(
            sx,
            sy
        )

        width = image_width * factor
        height = image_height * factor

    elif mode == "CONTAIN":

        factor = min(
            sx,
            sy
        )

        width = image_width * factor
        height = image_height * factor

    else:

        width = area_width
        height = area_height

    scale = max(
        0.01,
        float(scale)
    )

    return (
        width * scale,
        height * scale
    )


# =========================================================
# 绘制皮肤
# =========================================================

def draw_skin(area, slot):

    # -----------------------------------------------------
    # 绝对禁止覆盖3D View
    # -----------------------------------------------------

    if area.type == "VIEW_3D":
        return

    scene = bpy.context.scene

    settings = getattr(
        scene,
        "custom_skin_v7",
        None
    )

    if settings is None:
        return

    item = getattr(
        settings,
        slot,
        None
    )

    if item is None:
        return

    if not item.enabled:
        return

    if not item.image_path:
        return

    if item.opacity <= 0.001:
        return

    region = bpy.context.region

    if region is None:
        return

    data = get_texture(
        slot,
        item
    )

    if not data:
        return

    texture = data["texture"]

    image_width = data["width"]
    image_height = data["height"]

    region_width = max(
        1,
        region.width
    )

    region_height = max(
        1,
        region.height
    )

    draw_width, draw_height = calculate_size(
        region_width,
        region_height,
        image_width,
        image_height,
        item.fit_mode,
        item.scale
    )

    x = (
        region_width
        - draw_width
    ) * 0.5

    y = (
        region_height
        - draw_height
    ) * 0.5

    x += item.offset_x
    y += item.offset_y

    try:

        gpu.state.blend_set(
            "ALPHA"
        )

        draw_texture_2d(
            texture,
            (x, y),
            draw_width,
            draw_height
        )

    except Exception:
        pass

    finally:

        try:
            gpu.state.blend_set(
                "NONE"
            )
        except Exception:
            pass


# =========================================================
# 绘制回调
# =========================================================

def draw_callback():

    try:

        area = bpy.context.area

        if area is None:
            return

        # 绝对保护3D视图
        if area.type == "VIEW_3D":
            return

        slot = AREA_TO_SLOT.get(
            area.type
        )

        if slot is None:
            return

        draw_skin(
            area,
            slot
        )

    except Exception:
        pass


# =========================================================
# 属性
# =========================================================

class CUSTOM_SKIN_V7_Slot(
    bpy.types.PropertyGroup
):

    enabled: BoolProperty(
        name="启用",
        default=True
    )

    image_path: StringProperty(
        name="图片路径",
        subtype="FILE_PATH",
        default=""
    )

    image_name: StringProperty(
        name="图片",
        default="未选择"
    )

    opacity: FloatProperty(
        name="透明度",
        min=0.0,
        max=1.0,
        default=0.16,
        subtype="FACTOR"
    )

    scale: FloatProperty(
        name="缩放",
        min=0.01,
        max=10.0,
        default=1.0
    )

    offset_x: FloatProperty(
        name="水平位置",
        min=-10000.0,
        max=10000.0,
        default=0.0
    )

    offset_y: FloatProperty(
        name="垂直位置",
        min=-10000.0,
        max=10000.0,
        default=0.0
    )

    fit_mode: EnumProperty(
        name="显示方式",
        items=[
            (
                "FILL",
                "铺满区域",
                "保持比例铺满"
            ),
            (
                "CONTAIN",
                "完整显示",
                "保持比例完整显示"
            ),
            (
                "STRETCH",
                "拉伸区域",
                "拉伸至区域大小"
            ),
        ],
        default="FILL"
    )


class CUSTOM_SKIN_V7_Settings(
    bpy.types.PropertyGroup
):

    outliner: bpy.props.PointerProperty(
        type=CUSTOM_SKIN_V7_Slot
    )

    properties: bpy.props.PointerProperty(
        type=CUSTOM_SKIN_V7_Slot
    )

    timeline: bpy.props.PointerProperty(
        type=CUSTOM_SKIN_V7_Slot
    )

    topbar: bpy.props.PointerProperty(
        type=CUSTOM_SKIN_V7_Slot
    )


# =========================================================
# 选择图片
# =========================================================

class CUSTOM_SKIN_V7_OT_Load(
    bpy.types.Operator
):

    bl_idname = "custom_skin_v7.load"

    bl_label = "选择图片"

    slot: StringProperty()

    filepath: StringProperty(
        subtype="FILE_PATH",
        options={"HIDDEN"}
    )

    filter_glob: StringProperty(
        default="*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.tif;*.tiff",
        options={"HIDDEN"}
    )

    def invoke(
        self,
        context,
        event
    ):

        context.window_manager.fileselect_add(
            self
        )

        return {
            "RUNNING_MODAL"
        }

    def execute(
        self,
        context
    ):

        settings = context.scene.custom_skin_v7

        item = getattr(
            settings,
            self.slot
        )

        item.image_path = self.filepath

        item.image_name = (
            Path(
                self.filepath
            ).name
            if self.filepath
            else "未选择"
        )

        item.enabled = True

        clear_cache(
            self.slot
        )

        redraw_all(
            context
        )

        return {
            "FINISHED"
        }


# =========================================================
# 清除
# =========================================================

class CUSTOM_SKIN_V7_OT_Clear(
    bpy.types.Operator
):

    bl_idname = "custom_skin_v7.clear"

    bl_label = "清除"

    slot: StringProperty()

    def execute(
        self,
        context
    ):

        item = getattr(
            context.scene.custom_skin_v7,
            self.slot
        )

        item.image_path = ""
        item.image_name = "未选择"

        clear_cache(
            self.slot
        )

        redraw_all(
            context
        )

        return {
            "FINISHED"
        }


# =========================================================
# 重置
# =========================================================

class CUSTOM_SKIN_V7_OT_Reset(
    bpy.types.Operator
):

    bl_idname = "custom_skin_v7.reset"

    bl_label = "恢复默认"

    slot: StringProperty()

    def execute(
        self,
        context
    ):

        item = getattr(
            context.scene.custom_skin_v7,
            self.slot
        )

        item.enabled = True

        # Properties 默认降低透明度
        if self.slot == "properties":
            item.opacity = 0.10
        else:
            item.opacity = 0.16

        item.scale = 1.0

        item.offset_x = 0.0
        item.offset_y = 0.0

        item.fit_mode = "FILL"

        clear_cache(
            self.slot
        )

        redraw_all(
            context
        )

        return {
            "FINISHED"
        }


# =========================================================
# 刷新
# =========================================================

class CUSTOM_SKIN_V7_OT_Refresh(
    bpy.types.Operator
):

    bl_idname = "custom_skin_v7.refresh"

    bl_label = "刷新全部"

    def execute(
        self,
        context
    ):

        _TEXTURE_CACHE.clear()

        redraw_all(
            context
        )

        return {
            "FINISHED"
        }


# =========================================================
# 工具函数
# =========================================================

def clear_cache(slot):

    for key in list(
        _TEXTURE_CACHE.keys()
    ):

        if key[0] == slot:
            del _TEXTURE_CACHE[key]


def redraw_all(context):

    screen = context.screen

    if screen is None:
        return

    for area in screen.areas:

        try:
            area.tag_redraw()
        except Exception:
            pass


# =========================================================
# UI面板
# =========================================================

def draw_slot(
    layout,
    slot,
    title
):

    settings = bpy.context.scene.custom_skin_v7

    item = getattr(
        settings,
        slot
    )

    box = layout.box()

    # 标题
    row = box.row(
        align=True
    )

    row.label(
        text=title
    )

    row.prop(
        item,
        "enabled",
        text=""
    )

    # 当前图片
    row = box.row()

    row.label(
        text=item.image_name,
        icon="IMAGE_DATA"
    )

    # 选择图片
    op = box.operator(
        "custom_skin_v7.load",
        text="选择该区域图片",
        icon="FILEBROWSER"
    )

    op.slot = slot

    # 清除
    op = box.operator(
        "custom_skin_v7.clear",
        text="清除图片",
        icon="X"
    )

    op.slot = slot

    # 透明度
    box.prop(
        item,
        "opacity",
        slider=True
    )

    # 缩放
    box.prop(
        item,
        "scale"
    )

    # 水平
    box.prop(
        item,
        "offset_x"
    )

    # 垂直
    box.prop(
        item,
        "offset_y"
    )

    # 显示方式
    box.prop(
        item,
        "fit_mode"
    )

    # 恢复
    op = box.operator(
        "custom_skin_v7.reset",
        text="恢复该区域参数",
        icon="LOOP_BACK"
    )

    op.slot = slot


class CUSTOM_SKIN_V7_PT_Main(
    bpy.types.Panel
):

    bl_label = "Blender UI皮肤 V7"

    bl_idname = (
        "CUSTOM_SKIN_V7_PT_Main"
    )

    bl_space_type = "VIEW_3D"

    bl_region_type = "UI"

    bl_category = "Skin"

    def draw(
        self,
        context
    ):

        layout = self.layout

        # 核心提示
        box = layout.box()

        box.label(
            text="3D视图完全保护",
            icon="VIEW3D"
        )

        box.label(
            text="模型 / 网格 / Gizmo 不覆盖"
        )

        layout.separator()

        # 四个区域
        draw_slot(
            layout,
            "outliner",
            "① 大纲视图"
        )

        draw_slot(
            layout,
            "properties",
            "② 属性 / 修改器"
        )

        draw_slot(
            layout,
            "timeline",
            "③ 时间轴"
        )

        draw_slot(
            layout,
            "topbar",
            "④ 顶部栏"
        )

        layout.separator()

        box = layout.box()

        box.label(
            text="Properties建议透明度：0.05~0.15",
            icon="INFO"
        )

        box.label(
            text="这样可以最大程度保持原生控件清晰"
        )

        layout.operator(
            "custom_skin_v7.refresh",
            text="刷新全部皮肤",
            icon="FILE_REFRESH"
        )


# =========================================================
# 注册
# =========================================================

CLASSES = (

    CUSTOM_SKIN_V7_Slot,

    CUSTOM_SKIN_V7_Settings,

    CUSTOM_SKIN_V7_OT_Load,

    CUSTOM_SKIN_V7_OT_Clear,

    CUSTOM_SKIN_V7_OT_Reset,

    CUSTOM_SKIN_V7_OT_Refresh,

    CUSTOM_SKIN_V7_PT_Main,

)


# =========================================================
# 注册绘制回调
# =========================================================

def register_handlers():

    unregister_handlers()

    space_types = [

        bpy.types.SpaceOutliner,

        bpy.types.SpaceProperties,

        bpy.types.SpaceDopeSheetEditor,

        bpy.types.SpaceGraphEditor,

        bpy.types.SpaceNLA,

        bpy.types.SpaceNodeEditor,

        bpy.types.SpaceImageEditor,

        bpy.types.SpaceSequenceEditor,

        bpy.types.SpaceTextEditor,

        bpy.types.SpaceConsole,

        bpy.types.SpaceSpreadsheet,

        bpy.types.SpaceFileBrowser,

        bpy.types.SpaceClipEditor,

        bpy.types.SpaceInfo,

    ]

    for space_type in space_types:

        try:

            handler = (
                space_type.draw_handler_add(
                    draw_callback,
                    (),
                    "WINDOW",
                    "POST_PIXEL"
                )
            )

            _HANDLERS.append(
                (
                    space_type,
                    handler
                )
            )

        except Exception:
            pass

    # Top Bar
    topbar = getattr(
        bpy.types,
        "SpaceTopBar",
        None
    )

    if topbar is not None:

        try:

            handler = (
                topbar.draw_handler_add(
                    draw_callback,
                    (),
                    "WINDOW",
                    "POST_PIXEL"
                )
            )

            _HANDLERS.append(
                (
                    topbar,
                    handler
                )
            )

        except Exception:
            pass


# =========================================================
# 删除绘制回调
# =========================================================

def unregister_handlers():

    for space_type, handler in _HANDLERS:

        try:

            space_type.draw_handler_remove(
                handler,
                "WINDOW"
            )

        except Exception:
            pass

    _HANDLERS.clear()


# =========================================================
# 注册
# =========================================================

def register():

    for cls in CLASSES:

        bpy.utils.register_class(
            cls
        )

    bpy.types.Scene.custom_skin_v7 = (
        bpy.props.PointerProperty(
            type=CUSTOM_SKIN_V7_Settings
        )
    )

    register_handlers()


# =========================================================
# 注销
# =========================================================

def unregister():

    unregister_handlers()

    _TEXTURE_CACHE.clear()

    if hasattr(
        bpy.types.Scene,
        "custom_skin_v7"
    ):

        del bpy.types.Scene.custom_skin_v7

    for cls in reversed(CLASSES):

        try:

            bpy.utils.unregister_class(
                cls
            )

        except Exception:
            pass


if __name__ == "__main__":
    register()